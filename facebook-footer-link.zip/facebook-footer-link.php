<?php

/*
Plugin Name: Facebook Footer Link
Description: Ads a facebook profile link to the end of posts
Version: 1.0.0
Author: Billal Hossain
*/


// No one directly access our plugin
//Exit if Accessed Directly
 
if (!defined('ABSPATH')){
	exit;
	}

//Global options Variable
$ffl_options = get_option('ffl_settings');
	
// Load Script
require_once(plugin_dir_path(__FILE__) . '/includes/facebook-footer-link-scripts.php');

//Load content
require_once(plugin_dir_path(__FILE__) . '/includes/facebook-footer-link-content.php');

//Load settings file
if(is_admin()){
	require_once(plugin_dir_path(__FILE__) . '/includes/facebook-footer-link-settings.php');
}


